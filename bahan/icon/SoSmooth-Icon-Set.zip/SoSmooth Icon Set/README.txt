
So Smooth Icon Set by MiniSoft is licensed under a Creative Commons Attribution-Noncommercial-No Derivate 3.0.

||Thanks for Downloading||